import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, RefreshCw, X } from "lucide-react";

interface WorkoutTimerProps {
  isOpen: boolean;
  onClose: () => void;
  exerciseName: string;
}

export default function WorkoutTimer({ isOpen, onClose, exerciseName }: WorkoutTimerProps) {
  const [timeLeft, setTimeLeft] = useState(45);
  const [selectedTime, setSelectedTime] = useState(45);
  const [isRunning, setIsRunning] = useState(false);
  
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, timeLeft]);
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  const handleStart = () => {
    if (timeLeft === 0) {
      setTimeLeft(selectedTime);
    }
    setIsRunning(!isRunning);
  };
  
  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(selectedTime);
  };
  
  const handleSliderChange = (value: number[]) => {
    const newTime = value[0];
    setSelectedTime(newTime);
    if (!isRunning) {
      setTimeLeft(newTime);
    }
  };
  
  const timeOptions = [15, 30, 45, 60, 90, 120];
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="bg-white rounded-xl shadow-lg w-full max-w-md p-6">
        <div className="absolute top-4 right-4">
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-gray-400 hover:text-gray-600" 
            onClick={onClose}
          >
            <X />
          </Button>
        </div>
        
        <DialogHeader>
          <DialogTitle className="font-semibold text-xl mb-2 text-center">Exercise Timer</DialogTitle>
          <p className="text-gray-600 text-center">{exerciseName}</p>
        </DialogHeader>
        
        <div className="mb-8 flex flex-col items-center">
          <div className="text-6xl font-bold mb-2" id="timerDisplay">
            {formatTime(timeLeft)}
          </div>
          <div className="text-gray-500 text-sm">Seconds remaining</div>
        </div>
        
        <div className="flex w-full space-x-4 justify-center mb-6">
          <Button 
            className={`py-3 px-6 rounded-lg font-medium flex-1 flex justify-center items-center ${
              isRunning ? "bg-gray-200 text-gray-800" : "bg-primary text-white"
            }`}
            onClick={handleStart}
          >
            {isRunning ? (
              <>
                <Pause className="mr-2" /> Pause
              </>
            ) : (
              <>
                <Play className="mr-2" /> {timeLeft === 0 ? "Restart" : "Start"}
              </>
            )}
          </Button>
          <Button 
            variant="outline"
            className="bg-gray-200 text-gray-800 py-3 px-6 rounded-lg font-medium flex-1 flex justify-center items-center"
            onClick={handleReset}
          >
            <RefreshCw className="mr-2" /> Reset
          </Button>
        </div>
        
        <div className="w-full">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Adjust Time</span>
            <span className="text-sm text-gray-500">{selectedTime} sec</span>
          </div>
          
          <Slider 
            value={[selectedTime]} 
            min={15} 
            max={120} 
            step={15}
            onValueChange={handleSliderChange}
            disabled={isRunning}
          />
          
          <div className="flex justify-between text-xs text-gray-500 px-1 mt-2">
            {timeOptions.map(time => (
              <span key={time}>{time}s</span>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
