import { useState } from "react";
import { Routine, Exercise } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp, Play, Clock, Users } from "lucide-react";
import { useExercises } from "@/hooks/useExercises";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from "@/components/ui/accordion";

interface RoutineCardProps {
  routine: Routine;
  onStart: (routineId: number) => void;
}

export default function RoutineCard({ routine, onStart }: RoutineCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const { exercises } = useExercises();

  const getDuration = () => {
    return `${Math.floor(routine.duration / 60)} min`;
  };
  
  const getLastCompletedText = () => {
    if (!routine.lastCompleted) return "Not done yet";
    
    try {
      return `Last done: ${formatDistanceToNow(new Date(routine.lastCompleted), { addSuffix: true })}`;
    } catch (error) {
      return "Last done: recently";
    }
  };
  
  const getExerciseCount = () => {
    return routine.exercises.length;
  };

  const getExerciseDetails = (exerciseId: number): Exercise | undefined => {
    return exercises.find(ex => ex.id === exerciseId);
  };

  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-sm border border-gray-100">
      <div className="p-4">
        <h3 className="font-semibold mb-1">{routine.name}</h3>
        <div className="flex items-center text-sm text-gray-600 mb-3">
          <span className="flex items-center">
            <Clock className="mr-1 h-3 w-3" /> {getDuration()}
          </span>
          <span className="mx-2">•</span>
          <span className="flex items-center">
            <Users className="mr-1 h-3 w-3" /> {getExerciseCount()} exercises
          </span>
        </div>
        
        <div className="flex items-center justify-between mb-2">
          <div className="text-sm text-gray-500">{getLastCompletedText()}</div>
          <Button 
            variant="default" 
            size="sm"
            className="bg-primary text-white"
            onClick={() => {
              // Expand the routine details
              setIsExpanded(true);
              // Start the routine
              onStart(routine.id);
            }}
          >
            <Play className="mr-1 h-3 w-3" /> Start
          </Button>
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          className="w-full mt-2 text-gray-600 hover:text-primary"
          onClick={() => setIsExpanded(!isExpanded)}
        >
          {isExpanded ? (
            <span className="flex items-center">
              Hide details <ChevronUp className="ml-1 h-3 w-3" />
            </span>
          ) : (
            <span className="flex items-center">
              Show details <ChevronDown className="ml-1 h-3 w-3" />
            </span>
          )}
        </Button>
      </div>

      {isExpanded && (
        <div className="px-4 pb-4 border-t border-gray-100 pt-2">
          <h4 className="font-medium text-sm mb-2">Exercise Sequence:</h4>
          <Accordion type="single" collapsible className="w-full">
            {routine.exercises.map((exercise, index) => {
              const exerciseDetails = getExerciseDetails(exercise.exerciseId);
              if (!exerciseDetails) return null;
              
              return (
                <AccordionItem key={index} value={`exercise-${index}`} className="border-b border-gray-200 last:border-0">
                  <AccordionTrigger className="py-2 hover:no-underline">
                    <div className="flex items-start text-left">
                      <div className="bg-gray-100 rounded-full w-6 h-6 flex items-center justify-center mr-2 flex-shrink-0">
                        <span className="text-xs font-medium">{index + 1}</span>
                      </div>
                      <div>
                        <div className="font-medium text-sm">{exerciseDetails.name}</div>
                        <div className="text-xs text-gray-500">
                          {exercise.sets} sets × {exercise.reps ? `${exercise.reps} reps` : `${exercise.duration}s`}
                        </div>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pl-8 pr-2 pb-3 text-sm">
                    <div className="text-gray-700 mb-2">{exerciseDetails.description}</div>
                    
                    <div className="text-xs font-semibold text-gray-500 uppercase mt-2 mb-1">Key Instructions:</div>
                    <ul className="list-disc pl-5 text-xs space-y-1 text-gray-600">
                      {exerciseDetails.instructions.map((instruction, idx) => (
                        <li key={idx}>{instruction.title}: {instruction.keyPoint}</li>
                      ))}
                    </ul>
                    
                    <div className="mt-3 text-xs text-primary font-medium">
                      Target: {exerciseDetails.muscleGroups}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        </div>
      )}
    </div>
  );
}
